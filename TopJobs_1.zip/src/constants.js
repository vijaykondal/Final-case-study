export const API_BASE_URL="http://localhost:3000"

//Regex for Valid email. 
export const emailRegExp = RegExp(
    /^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/
)

 //Regex for Valid Characters i.e. Alphabets and Space. 
 export const nameRegExp = RegExp(
    /^[A-Za-z ]+$/
)

export const messageValidation={
    max:150,
    min:10
}
export const validationMessage={
    email:"Email address is invalid.",
    phone:"Phone should be 10 digit number.",
    message:"Message can not be less than 10 characters and more than 150 characters.",
    name:"Number and special characters are not allowed.",
    requireMsg:"Filed is required."
}