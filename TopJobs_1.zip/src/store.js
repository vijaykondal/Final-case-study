import { combineReducers, configureStore } from "@reduxjs/toolkit";
import messageReducer from "./component/Contact/messageReducer";
import applyJobReducer from "./component/Job/jobReducer";

const rootReducer= combineReducers({
    message:messageReducer,
    job:applyJobReducer
})

const store= configureStore({
    reducer : rootReducer
    }

)
export default store;