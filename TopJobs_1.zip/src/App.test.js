import { render, screen,  } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import App from './App';
import {MemoryRouter, Router } from 'react-router-dom'
import {createMemoryHistory} from 'history'
import '@testing-library/jest-dom'

describe('test app component',()=>{
it('renders app component', async() => {
  render(<App />); 
    const linkElement = await screen.getByText(/home/i);
    expect(linkElement).toBeInTheDocument();
 
});

})
