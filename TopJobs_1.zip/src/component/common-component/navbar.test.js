const mockedUsedNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
   ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));
import {render ,screen} from '@testing-library/react';
import NavBar from './navbar';
import user from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';


describe('test Navbar component',()=>{

    beforeEach(()=>{
        
        render(<MemoryRouter>
        <NavBar/> </MemoryRouter>);
    })
    // it('render navbar component',()=>{
    //     render(<NavBar/>);             
    // })

    it('home link clicked in navbar', async()=>{       
       const routerLink= screen.getByTestId('homeRoutLink');
      await user.click(routerLink);
      expect(routerLink).toHaveClass('isActive');      
    })

    it('contact us link clicked in navbar', async()=>{       
        const routerLink= screen.getByTestId('contactUsRoutLink');
       await user.click(routerLink);
 
       expect(routerLink).toHaveClass('isActive');      
     })
     
     it('jobs link clicked in navbar', async()=>{       
        const routerLink= screen.getByTestId('jobRoutLink');
       await user.click(routerLink);
 
       expect(routerLink).toHaveClass('isActive');      
     })

})