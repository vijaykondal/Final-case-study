

const Loader = () => {
    return (
        <div className="text-center mt-5">
             <div className="spinner-border ml-auto" role="status" aria-hidden="true"></div>
            <div>
            <strong>Loading...</strong>
            </div>
           
        </div>
    )
}

export default Loader;