import {render ,screen} from '@testing-library/react';
import Loader from './loader';

describe('test Loader component',()=>{

    it('render Loader component',()=>{
        render(<Loader/>);        
    })
})