import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import NotFound from './notFound';

describe('test NorFound component', () => {

    it('render NorFound component', () => {
        render(<MemoryRouter>
            <NotFound />
        </MemoryRouter>);
    })
})