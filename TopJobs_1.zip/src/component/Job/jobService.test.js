import { mockApplyJobData, mockJobListData } from "../../tests.data";
import { getJobListAction,applyJobAction } from "./appyJobService";
import store from '../../store'
import { API_BASE_URL } from "../../constants";
import axios from "axios";

describe("test job action", () => { 

  it("joblist action should be return array of job list", async () => {
    const getSpy = jest.spyOn(axios, 'get').mockResolvedValueOnce({ data: mockJobListData });
    const result = await store.dispatch(getJobListAction());
    const users = result.payload;
    console.log(users)
    expect(getSpy).toBeCalledWith(`${API_BASE_URL}/jobList`);
    expect(result.type).toBe("jobs/getJobList/fulfilled");
    const state= store.getState();
    expect(state.job.jobList.length).toBe(2)   

  });

  it("apply action should pass data and get rejected", async () => {
    const postSpy = jest.spyOn(axios, 'post').mockResolvedValueOnce({ data: mockApplyJobData });
    const result = await store.dispatch(applyJobAction(mockApplyJobData));   
    expect(result.type).toBe("jobs/applyJob/rejected");
 
  
  });

  // it("apply action should pass data ", async () => {
  //   const postSpy = jest.spyOn(axios, 'post').mockResolvedValueOnce({ data: mockApplyJobData });
  //   const result = await store.dispatch(applyJobAction(mockApplyJobData));
  //   const users = result;
  //   console.log('apply vijay', users)
  // // expect(postSpy).toBeCalledWith(`${API_BASE_URL}/jobs`,mockApplyJobData);
  //   expect(result.type).toBe("jobs/applyJob/fulfilled");
  // //  const state= store.getState();
  // //  console.log(state)
  //   //expect(state.job.jobList.length).toBe(2)   
  
  // });


});


