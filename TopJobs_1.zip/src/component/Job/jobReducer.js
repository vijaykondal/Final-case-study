import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import { applyJobAction,getJobListAction } from "./appyJobService";

const applyJobSlice= createSlice({
    name:'job',
    initialState:{jobs:[],jobList:[]},
    extraReducers: {
        [applyJobAction.fulfilled]: (state, action) => {
           // console.log(state)
            state.jobs.push(action.payload)
              toast.success('You have successfully applied.')
        },
        [applyJobAction.rejected]: (state, action) => {
            // console.log(state)            
               toast.error('Server error.')
         },
         [getJobListAction.fulfilled]: (state, action) => {
            // console.log(state)
             state.jobList=action.payload;              
         },
         [getJobListAction.rejected]: (state, action) => {
             // console.log(state)            
             toast.error('Network Error.')
          }
    }

})



export default applyJobSlice.reducer;


