import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import store from "../../store";
import JobCard from "./jobCard";
import { getJobListAction } from "./appyJobService";
import NotFound from "../common-component/notFound";


const JobList = () => {   
    const jobListArr= useSelector((state)=> state.job.jobList)
    console.log(jobListArr);
    const dispatch=useDispatch();
    useEffect(()=>{
        dispatch(getJobListAction());
    },[])

    return (
        <div data-testid='jobsContainer'>
           { jobListArr.length>0 ?<JobCard jobList={jobListArr} />:<NotFound/>}
        </div>
    )
}
export default JobList;