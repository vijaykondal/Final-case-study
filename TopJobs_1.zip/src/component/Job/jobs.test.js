import { MemoryRouter } from "react-router-dom";
import { render ,screen} from "../../test-util";
import JobList from "./Jobs";


describe('test JobList component',()=>{
    it('Job component should render',()=>{
        render(
        <MemoryRouter><JobList/></MemoryRouter>)        
    })
})