import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { API_BASE_URL } from "../../constants";

export const addMessage = createAsyncThunk(
    'message/addMessage',
    async (obj) => {       
        const res = await axios.post(`${API_BASE_URL}/messages`, JSON.parse(obj));
        return res;
    }
)