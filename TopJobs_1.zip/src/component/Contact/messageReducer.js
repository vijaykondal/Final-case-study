import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import { addMessage } from "./message-service";

const messageSlice= createSlice({
    name:'message',
    initialState:{messages:[]},
    extraReducers: {
        [addMessage.fulfilled]: (state, action) => {
           // console.log(state)
            state.messages.push(action.payload)
              toast.success('Messge succesfylly saved.')
        },
        [addMessage.rejected]: (state, action) => {
            // console.log(state)            
               toast.error('Network Error.');
         },
    }

})



export default messageSlice.reducer;


