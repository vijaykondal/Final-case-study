import GetInTouch from "./getinTouch";
import { render,screen } from "@testing-library/react";
import user from '@testing-library/user-event';
import { validationMessage } from "../../constants";

describe('test GetInTouch component',()=>{


    it('render GetInTouch component',()=>{
        const container= render(<GetInTouch/>);
        const element= screen.getByTestId('getIntouchHeader')
        expect(element.textContent).toEqual('Get In Touch');
    })

})

describe('test GetInTouch form control validation',()=>{

    let buttonElement ; 
   
    beforeEach( async()=>{
      render(<GetInTouch/>); 
       buttonElement= await screen.getByTestId('getIntouchSubBtn');      
    })

    it('number value should not allow in name form control', async()=>{ 
            
       const inputElement= await screen.getByRole('textbox', { name: /name/i });       
       //provide nuber value
       user.type(inputElement, '123');   
       await user.click(buttonElement);
       expect(screen.queryByText(validationMessage.name).textContent).toEqual(validationMessage.name);
       expect(inputElement).toHaveClass("is-invalid");       
    })

    it('special character should not allow in name form control', async()=>{          
        const inputElement1= await screen.getByRole('textbox', { name: /name/i });
         //provide special character
        user.type(inputElement1, 'abc@#');     
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.name).textContent).toEqual(validationMessage.name);
        expect(inputElement1).toHaveClass("is-invalid");       
     })
     it('name form control allow valid value(i:e not numbert,special character)', async()=>{          
        const inputElement1= await screen.getByRole('textbox', { name: /name/i });
         //provide special character
        user.type(inputElement1, 'test value');     
        await user.click(buttonElement);
        expect(inputElement1).not.toHaveClass("is-invalid");       
     })

     it('should not allow invalid email in email form control', async()=>{          
        const inputElement= await screen.getByRole('textbox', { name: /emailId/i });      
         //provide invalid eamil 
        user.type(inputElement, 'abc1234');     
        await user.click(buttonElement); 
        expect(screen.queryByText(validationMessage.email).textContent).toEqual(validationMessage.email);      
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('should allow valid email in email form control', async()=>{          
        const inputElement= await screen.getByRole('textbox', { name: /emailId/i });
         //provide invalid eamil 
        user.type(inputElement, 'abc@gmail.com');     
        await user.click(buttonElement);
        expect(inputElement).not.toHaveClass("is-invalid");       
     })

     it('phone should other then 10 digit number', async()=>{ 
        const inputElement= await screen.getByTestId('phoneNum'); 
        user.type(inputElement, '12345');     
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.phone).textContent).toEqual(validationMessage.phone);      
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('phone should be 10 digit number', async()=>{ 
        const inputElement= await screen.getByTestId('phoneNum'); 
        user.type(inputElement, '8285584334');     
        await user.click(buttonElement);       
        expect(inputElement).not.toHaveClass("is-invalid");       
     })
     
     it('message should be be not less then 10 charater', async()=>{          
        const inputElement= await screen.getByTestId('gmessage');        
        user.type(inputElement, 'abc');     
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.message).textContent).toEqual(validationMessage.message);
        expect(inputElement).toHaveClass("is-invalid");      
     })

     it('message should be be  in between 10 to 150 character', async()=>{          
        const inputElement= await screen.getByTestId('gmessage');
        user.type(inputElement, "test valid input that is in between 10 to 150 character.")
        await user.click(buttonElement);       
        expect(inputElement).not.toHaveClass("is-invalid");      
     })
   
})