import { mockAddMessageData} from "../../tests.data";
import store from '../../store'
import { API_BASE_URL } from "../../constants";
import axios from "axios";
import { addMessage } from "./message-service";

describe("test message action", () => { 

//   it("joblist action should be return array of job list", async () => {
//     const getSpy = jest.spyOn(axios, 'get').mockResolvedValueOnce({ data: mockJobListData });
//     const result = await store.dispatch(getJobListAction());
//     const users = result.payload;
//     console.log(users)
//     expect(getSpy).toBeCalledWith(`${API_BASE_URL}/jobList`);
//     expect(result.type).toBe("jobs/getJobList/fulfilled");
//     const state= store.getState();
//     expect(state.job.jobList.length).toBe(2)   

//   });

  it("add message action should pass data and get rejected", async () => {
    const postSpy = jest.spyOn(axios, 'post').mockResolvedValueOnce({ data: mockAddMessageData });
    const result = await store.dispatch(addMessage(mockAddMessageData));   
    expect(result.type).toBe("message/addMessage/rejected");
 
  
  });



});


