import React from "react";
import { emailRegExp, messageValidation, nameRegExp, validationMessage } from "../../constants";
import contactUsImg from '../../Assets/images/contactUs.jpg'
import './contact-us.css'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";
import { useDispatch } from "react-redux";
import { addMessage } from "./message-service";
import store from "../../store";



const formValid = ({ isError, ...rest }) => {
    let isValid = false;
    let error = []
    Object.values(isError).forEach(val => {
        if (val.length > 0) {
            isValid = false;
            error.push('error')
        }
    });
    // if (error.length == 0) {
    //     if (rest.emailId !== '' || rest.phone != "" || rest.message != '' || rest.name != "") {
    //         isValid = true;
    //     } else {
    //         isValid = false
    //     }
    // } else {
    //     isValid = false
    // }
    if (error.length > 0) {
        isValid = false
    }else{
        isValid = true 
    }

    return isValid;
};
export default class GetInTouch extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            name: '',
            emailId: '',
            phone: '',
            message: '',
            isSubmitButtonDisable: true,
            isError: {
                name: '',
                emailId: '',
                phone: '',
                message: ''
            }

        }

    }

    onSubmit = e => {
        e.preventDefault();
        if (formValid(this.state)) {
            console.log(this.state);

            store.dispatch(addMessage(JSON.stringify({
                name: this.state.name,
                emailId: this.state.emailId, message: this.state.message, phone: this.state.phone
            })))
            e.target.reset();
            this.isSubmitDisable({name:'',emailId:'',message:'',phone:''})
        } else {
            toast.error('Form is invalid!')
        }
    };

    formValChange = e => {
        e.preventDefault();
        const { name, value } = e.target;
        let isError = { ...this.state.isError };

        switch (name) {
            case "name":
                isError.name = (value.length > 0 && !nameRegExp.test(value))
                    ? validationMessage.name : "";
                break;
            case "emailId":
                isError.emailId = (value.length > 0 && !emailRegExp.test(value))
                    ? validationMessage.email : '';
                break;
            case "phone":
                isError.phone =
                    (value.length > 0 && value.length !== 10) ? validationMessage.phone : "";
                break;
            case "message":
                isError.message =
                    (value.length > 0 && (value.length < 10 || value.length > 150)) ? validationMessage.message : "";
                break;
            default:
                break;
        }
        let obj = {
            ...this.state,
            isError,
            [name]: value
        }
        this.setState(() => {
            return obj
        })
        this.isSubmitDisable(obj);
    };
    isSubmitDisable = (obj) => {
        if (obj.name === '' && obj.emailId === '' && obj.phone === '' && obj.message === '') {
            this.setState((prevState) => {               
                return prevState.isSubmitButtonDisable = true;
            })
        } else {
            this.setState((prevState) => {              
                return prevState.isSubmitButtonDisable = false;
            })
        }

    }
    render() {
        const { isError } = this.state;
        return (
            <div className='container'>
                <div className="row pb-2">
                    <div className="col-md-6 col-xs-12">
                        <div>
                            <h4 data-testid="getIntouchHeader" className="text-danger text-center">Get In Touch</h4>
                        </div>
                        <form onSubmit={this.onSubmit} noValidate>
                            <div className="form-group mt-3">

                                <input
                                    type="text"
                                    className={isError.name.length > 0 ? "is-invalid form-control" : "form-control"}
                                    name="name"
                                    placeholder="Name"
                                    title="Name"
                                    onChange={this.formValChange}
                                />
                                {isError.name.length > 0 && (
                                    <span className="invalid-feedback">{isError.name}</span>
                                )}
                            </div>
                            <div className="form-group mt-3">

                                <input
                                    type="email"
                                    className={isError.emailId.length > 0 ? "is-invalid form-control" : "form-control"}
                                    name="emailId"
                                    title='emailId'
                                    placeholder="Email"
                                    onChange={this.formValChange}
                                />
                                {isError.emailId.length > 0 && (
                                    <span data-testid='emailErrorContainer' className="invalid-feedback">{isError.emailId}</span>
                                )}
                            </div>
                            <div className="form-group mt-3">
                                <input
                                    type="number"
                                    className={isError.phone.length > 0 ? "is-invalid form-control" : "form-control"}
                                    name="phone"
                                    title="Phone"
                                    placeholder="Phone"
                                    data-testid='phoneNum'
                                    onChange={this.formValChange}
                                />
                                {isError.phone.length > 0 && (
                                    <span className="invalid-feedback">{isError.phone}</span>
                                )}
                            </div>
                            <div className="form-group mt-3">
                                <textarea maxLength={messageValidation.max} minLength={messageValidation.min}
                                    className={isError.message.length > 0 ? "is-invalid form-control" : "form-control"}
                                    data-testid="gmessage" placeholder="Message" name="message" onChange={this.formValChange} />

                                {isError.message.length > 0 && (
                                    <span className="invalid-feedback">{isError.message}</span>
                                )}
                            </div>
                            <div className="text-center"> <button type="submit" disabled={this.state.isSubmitButtonDisable} data-testid='getIntouchSubBtn' className="btn btn-block btn-danger mt-3 mb-1">Submit</button></div>

                        </form>
                    </div>
                    <div className="col-md-6 col-sm-12">
                        <img className="contactus-banner" src={contactUsImg} />
                    </div>
                </div>
            </div>
        );
    }
}