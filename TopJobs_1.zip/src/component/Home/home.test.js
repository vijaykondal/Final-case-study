import { render, screen, waitFor } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import Home from './home';

test('render Home component', async() => {
  render(<Home />); 
    const linkElement = screen.getByText(/Coming Soon/i);
    expect(linkElement).toBeInTheDocument(); 
});
