import React from "react";
import { Carousel } from "react-bootstrap";
import carousel1 from '../../Assets/images/carousel_1.jpg'
import carousel2 from '../../Assets/images/carousel_2.jpg'
import carousel3 from '../../Assets/images/carousel_3.jpg'
import './home.css'


const CarouselComp = () => {
    return (
        <Carousel variant="dark" className="justify-content-denter" interval={1000}>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src={carousel1}
                    alt="Job in IT"
                />
                <Carousel.Caption>
                    <h3>Job in IT</h3>
                    <p>Jobs related to Software development is on boom.</p>
                </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src={carousel2}
                    alt="Health care job"
                />

                <Carousel.Caption>
                    <h3>Job in Health care</h3>
                    <p>Jobs in health care is good career.</p>
                </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src={carousel3}
                    alt="Business career"
                />

                <Carousel.Caption>
                    <h3>Manager career</h3>
                    <p>
                        Manager desgin your workflow to achieve your company goal.
                    </p>
                </Carousel.Caption>
            </Carousel.Item>
        </Carousel>

    )
}

export default CarouselComp;