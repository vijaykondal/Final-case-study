import React from "react";
import CarouselComp from './carousel';
import { Badge } from "react-bootstrap";


const Home = () => {
    return (
        <>
            <div className="row">
                <CarouselComp />
            </div>
            <div className="row py-4">
                <div className="col-md-4 col-sm-12 text-center">
                    <h1>
                        <Badge bg="secondary"> <a className="link-class" href="/job">Jobs</a></Badge>
                    </h1>
                </div>
                <div className="col-md-4 col-sm-12 text-center">
                    <h1>
                        <Badge bg="secondary"> <a className="link-class" href="/contactUS">Contact US</a></Badge>
                    </h1>
                </div>
                <div className="col-md-4 col-sm-12 text-center">
                    <h1>
                        <Badge bg="secondary" >Coming Soon</Badge>
                    </h1>
                </div>

            </div>

        </>
    )
}

export default Home;