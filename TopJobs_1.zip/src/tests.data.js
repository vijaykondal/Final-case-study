
const mockJobListData = [
    {
        "jobId": 10003,
        "jobRole": "SAP FICO Consultant",
        "company": "Bhavana Balkrishna Goveker",
        "expectedExperence": "2-8",
        "salary": "237000-700000",
        "location": "Mumbai"
      },
      {
        "jobId": 10004,
        "jobRole": "Assistant Manager-PLM",
        "company": "Indigo Airline",
        "expectedExperence": "1-6",
        "salary": "Not disclosed",
        "location": "remote"
      }
];

const mockApplyJobData=
  {
    "job_id":"143", "name": "mockName",
    "email": 'moc@gmail.com', "experience":'expe in Angular and reactjs', "phone":"1234567890", "address": "test mock address data"
  }
const mockAddMessageData={
  name: 'Raj kumar',
  emailId: 'rj@gmail.com', message: "Test message for ui and Reackjs", phone: '1234567890'
}



export { 
  mockJobListData,
  mockApplyJobData,
  mockAddMessageData
};