import {lazy, React, Suspense } from 'react';
import './App.css';
import NavBar from './component/common-component/navbar';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import { Provider } from 'react-redux';
import store from './store';
import Loader from './component/common-component/loader';
//import NotFound from './component/common-component/notFound';

//Lazy loading
const Home = lazy(() => import("./component/Home/home"));
const JobList = lazy(() => import("./component/Job/Jobs"));
const Contact = lazy(() => import("./component/Contact/contact"));
const NotFound = lazy(() => import("./component/common-component/notFound"));



function App() {
  return (
    
    <div className="container font-face-bodoniFLF-Bold">      
      <BrowserRouter> 
         <Provider store={store}>
        <NavBar />
        <div className='boxshadow'>
        <Suspense fallback={<Loader/>}>
        <Routes>
          
          <Route exact path='/' element={<Navigate to="/home" />}/>
          <Route exact path='/home' element={<Home/>}/>
          <Route exact path='/contactUs' element={<Contact/>}/>
          <Route exact path='/job' element={<JobList/>}/>
          <Route path='*' element={<NotFound/>}/>
        </Routes>
        </Suspense>
        </div>
        </Provider>
      </BrowserRouter>
      <ToastContainer closeButton={false} position="top-right" />
    
    </div>
  );
}

export default App;
