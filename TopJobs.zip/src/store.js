import { configureStore } from "@reduxjs/toolkit";
import messageReducer from "./component/Contact/messageReducer";
import applyJobReducer from "./component/Job/jobReducer";
import { applyJobAction } from "./component/Job/appyJobService";


const store= configureStore({
    reducer :{
        message:messageReducer,
        job:applyJobReducer
        // middleware: (getDefaultMiddleware) =>{
        // curryGetDefaultMiddleware({
        //   serializableCheck: {
        //     // Ignore these action types/
        //     ignoredActions: [applyJobAction],
        //     // // Ignore these field paths in all actions
        //     // ignoredActionPaths: ['meta.arg', 'payload.timestamp'],
        //     // // Ignore these paths in the state
        //     // ignoredPaths: ['items.dates'],
        //   }
        // })
   // }
    
    }
}
)
export default store;