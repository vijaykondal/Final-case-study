import React, { useEffect, useState} from "react";
import { Navbar, Container, Nav } from 'react-bootstrap';
import { useNavigate,useLocation } from "react-router-dom";


const NavBar = () => {
  const location = useLocation();
  const [activeMenu,setActiveMenu]=useState()
const navigate= useNavigate();
  const hanelClick=(menuName)=>{
    navigate(`/${menuName}`);
    setActiveMenu(menuName);   
  }
  useEffect(()=>{   
    let menuName= location.pathname;
  console.log(menuName.substring(1,menuName.length))
    setActiveMenu(menuName.substring(1,menuName.length))

  },[])

    return (
        <div>          
        <Navbar  expand="sm">
          <Container>
            <Navbar.Brand href="/home">             
              <div  style={{fontWeight: 900}}>
                Top Job
              </div>
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="navBar" />
            <Navbar.Collapse id="navBar">
              <Nav className="col justify-content-end me-auto">               
                <Nav.Link data-testid='homeRoutLink'  href="" className={activeMenu =='home'&& 'isActive'} onClick={()=>{hanelClick('home')}}>HOME</Nav.Link> 
                <Nav.Link  data-testid='contactUsRoutLink'  className={activeMenu =='contactUS'&& 'isActive'} href='' onClick={()=>{hanelClick('contactUS')}}>CONTACT US</Nav.Link>
                <Nav.Link  data-testid='jobRoutLink'  href="" className={activeMenu =='job'&& 'isActive'} onClick={()=>{hanelClick('job')}}>JOBS</Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>       
       
      </div>
    )
}

export default NavBar;