import { render,screen } from "@testing-library/react";
import ApplyJobModal from "./applyJobModal";
import user from '@testing-library/user-event';
import {validationMessage} from '../../constants';

describe('test apply job component',()=>{
       
    let buttonElement;
    beforeEach( async() => {
        const container = document.createElement("div");
       
        render( <ApplyJobModal show={true}/> , container);
        buttonElement= await screen.getByTestId('applyJobBtn'); 
    });

    it('name validation, number not allow', async()=>{ 
            
        const inputElement= await screen.getByRole('textbox', { name: /name/i });       
        //provide nuber value
        user.type(inputElement, '123');   
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.name).textContent).toEqual(validationMessage.name);
        expect(inputElement).toHaveClass("is-invalid");       
     })
     it('name validation, special character not allow', async()=>{          
        const inputElement1= await screen.getByRole('textbox', { name: /name/i });
         //provide special character
        user.type(inputElement1, 'abc@#');     
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.name).textContent).toEqual(validationMessage.name);
        expect(inputElement1).toHaveClass("is-invalid");       
     })

     it('required validation for name', async()=>{          
        const inputElement= await screen.getByRole('textbox', { name: /name/i });
         //provide empty string
        user.type(inputElement, '');     
        await user.click(buttonElement);
        let errorContainer= screen.getByTestId('reqName')
        expect(errorContainer.textContent).toEqual(validationMessage.requireMsg);
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('name form control allow valid value(i:e not numbert,special character)', async()=>{          
        const inputElement1= await screen.getByRole('textbox', { name: /name/i });
         //provide special character
        user.type(inputElement1, 'test value');     
        await user.click(buttonElement);
        expect(inputElement1).not.toHaveClass("is-invalid");       
     })

     it('should not allow invalid email in email form control', async()=>{          
        const inputElement= await screen.getByRole('textbox', { name: /emailId/i });      
         //provide invalid eamil 
        user.type(inputElement, 'abc1234');     
        await user.click(buttonElement); 
        expect(screen.queryByText(validationMessage.email).textContent).toEqual(validationMessage.email);      
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('required validation for email', async()=>{          
        const inputElement= await screen.getByRole('textbox', { name: /emailId/i });
         //provide empty string
        user.type(inputElement, '');     
        await user.click(buttonElement);
        let errorContainer= screen.getByTestId('reqEmail')
        expect(errorContainer.textContent).toEqual(validationMessage.requireMsg);
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('should allow valid email in email form control', async()=>{          
        const inputElement= await screen.getByRole('textbox', { name: /emailId/i });
         //provide invalid eamil 
        user.type(inputElement, 'abc@gmail.com');     
        await user.click(buttonElement);
        expect(inputElement).not.toHaveClass("is-invalid");       
     })

     it('phone should other then 10 digit number', async()=>{ 
        const inputElement= await screen.getByTestId('empPhone'); 
        user.type(inputElement, '12345');     
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.phone).textContent).toEqual(validationMessage.phone);      
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('required validation for phone', async()=>{          
        const inputElement= await screen.getByTestId('empPhone');
         //provide empty string
        user.type(inputElement, '');     
        await user.click(buttonElement);
        let errorContainer= screen.getByTestId('reqPhone')
        expect(errorContainer.textContent).toEqual(validationMessage.requireMsg);
        expect(inputElement).toHaveClass("is-invalid");       
     })

     it('phone should be 10 digit number', async()=>{ 
        const inputElement= await screen.getByTestId('empPhone'); 
        user.type(inputElement, '8285584334');     
        await user.click(buttonElement);       
        expect(inputElement).not.toHaveClass("is-invalid");       
     })
     
     it('experience should be be not less then 10 charater', async()=>{          
        const inputElement= await screen.getByTestId('experience');        
        user.type(inputElement, 'abc');     
        await user.click(buttonElement);
        expect(screen.queryByText(validationMessage.message).textContent).toEqual(validationMessage.message);
        expect(inputElement).toHaveClass("is-invalid");      
     })

     it('experience should be in between 10 to 150 character', async()=>{          
        const inputElement= await screen.getByTestId('experience');
        user.type(inputElement, "test valid input that is in between 10 to 150 character.")
        await user.click(buttonElement);       
        expect(inputElement).not.toHaveClass("is-invalid");      
     })
     it('required validation for experience', async()=>{          
        const inputElement= await screen.getByTestId('experience');
         //provide empty string
        user.type(inputElement, '');     
        await user.click(buttonElement);
        let errorContainer= screen.getByTestId('reqExperience')
        expect(errorContainer.textContent).toEqual(validationMessage.requireMsg);
        expect(inputElement).toHaveClass("is-invalid");       
     })
        
})

// describe('close modal', () => {
//     const element = document.createElement('div');
//     const closeFn = jest.fn();
//     beforeEach(() => {
//         ReactDOM.render(
//             <ApplyJobModal closeFn={closeFn}>Hello World</ApplyJobModal>
//         , element);
//     });
//     afterEach(() => {
//        ReactDOM.un(element);
//        closeFn.mockReset();
//     });
//     it('when ESC key is pressed', () => {
//         var evt = new KeyboardEvent('keydown', { keyCode: 27 });
//         document.dispatchEvent(evt);
//         expect(closeModal).toHaveBeenCalledTimes(1);
//     });
//     it('closes modal if document is clicked', () => {
//         const evt = new MouseEvent('click', { bubbles: true });
//         document.dispatchEvent(evt);
//         expect(closeFn).toHaveBeenCalledTimes(1);
//     });
//     it('does not close if modal is clicked', () => {
//         const evt = new MouseEvent('click', { bubbles: true });
//         const modal = document.body.querySelector('.modal');
//         modal.dispatchEvent(evt);
//         expect(closeFn).toHaveBeenCalledTimes(0);
//     });
// });