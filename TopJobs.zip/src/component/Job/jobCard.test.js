import { render,screen } from "@testing-library/react";
import JobCard from "./jobCard";
import user from '@testing-library/user-event'

describe('test JobCard component',()=>{
let MockJobList=[
    {
        "jobId": 10001,
        "jobRole": "Sales Manager",
        "company": "SRG International",
        "expectedExperence": "4-6",
        "salary": "257000-400000",
        "location": "Faridabad"
    },
    {
        "jobId": 10002,
        "jobRole": "Account Officer - Banking",
        "company": "KAYPEE FOOD PRODUCTS",
        "expectedExperence": "2-8",
        "salary": "557000-800000",
        "location": "Delhi"
    }
]

    it('job card should be render',()=>{
      const {container}=  render(<JobCard jobList={MockJobList}/>)
       let element= container.getElementsByClassName('card-container')
       expect(element.length).toBe(2)
    })
    it('job card  fire click event test applyjobModal is open',async()=>{
        const {container}=  render(<JobCard jobList={MockJobList}/>)
         let element= container.getElementsByClassName('card-container');
       await user.click(element[0]);
      let buttonElement= await screen.getByTestId('applyJobBtn'); 
         expect(buttonElement).toBeInTheDocument()
      })

})