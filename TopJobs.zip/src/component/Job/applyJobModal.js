import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import { emailRegExp, messageValidation, nameRegExp, validationMessage } from "../../constants";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import store from '../../store';
import { applyJobAction } from './appyJobService';

const formValid = (error, formData) => {
  let isValid = false;
  let errorArr = []
  Object.values(error).forEach(val => {
    if (val.length > 0) {
      errorArr.push('error')
    }
  });
  if (errorArr.length == 0) {
    if (formData.name === '' || formData.emailId === "" || formData.phone === "" || formData.experience === "") {
      isValid = false;
    } else {
      isValid = true;
    }
  } else {
    isValid = false
  }
  return isValid;
};

const defaultErrorMessage = {
  name: '',
  emailId: '',
  phone: '',
  experience: ''
}
const initialValue = {
  name: '',
  emailId: '',
  phone: '',
  address: '',
  experience: '',
  isFormSubmit: false
}

function ApplyJobModal(props) {
  const [error, setError] = useState(defaultErrorMessage);
  const [data, setData] = useState(initialValue);

  const applyJob = e => {
    e.preventDefault();
    setData({ ...data, ...{ isFormSubmit: true } })
    if (formValid(error, data)) {
      store.dispatch(applyJobAction(JSON.stringify({
        job_id: props.data.jobId, name: data.name,
        email: data.emailId, experience: data.experience, phone: data.phone, address: data.address
      })))
      props.onHide()
    } else {
      toast.error('Form has invalid!')
    }
  };

  const formValChange = e => {
    e.preventDefault();
    const { name, value } = e.target;
    let isError = { ...error };

    switch (name) {
      case "name":
        isError.name = !nameRegExp.test(value)
          ? validationMessage.name : "";
        break;
      case "emailId":
        isError.emailId = !emailRegExp.test(value)
          ? validationMessage.email : '';
        break;
      case "phone":
        isError.phone =
          (value.length !== 10) ? validationMessage.phone : "";
        break;
      case "experience":
        isError.experience =
          (value.length < 10 || value.length > 150) ? validationMessage.message : "";
        break;

      default:
        break;
    }
    setError({
      ...isError
    })
    setData({
      ...data, ...{ [name]: value }
    })
  };

  //create all validation message when modal is closed
  const oneExitFromModal = () => {
    setError(defaultErrorMessage);
    setData(initialValue);
  }
  return (
    <>

      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        onExited={oneExitFromModal}
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">            
            Apply Job - {props.data && <span className='text-muted'>{props.data.jobRole}</span>}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className='container'>
            <div className="row">
              <form noValidate>
                <div className="form-group mt-3">

                  <input
                    type="text"
                    className={error.name.length > 0 || (data.isFormSubmit && !data.name) ? "is-invalid form-control" : "form-control"}
                    name="name"
                    placeholder="Name"
                    title="Name"
                    onChange={formValChange}
                  />
                  {error.name.length > 0 && (
                    <span className="invalid-feedback">{error.name}</span>
                  )}
                  {data.isFormSubmit && !data.name && (<span data-testid='reqName' className="invalid-feedback">{validationMessage.requireMsg}</span>)}
                </div>
                <div className="form-group mt-3">

                  <input
                    type="email"
                    className={error.emailId.length > 0 || (data.isFormSubmit && !data.emailId) ? "is-invalid form-control" : "form-control"}
                    name="emailId"
                    title='emailId'
                    placeholder="Email"
                    onChange={formValChange}
                  />
                  {error.emailId.length > 0 && (
                    <span className="invalid-feedback">{error.emailId}</span>
                  )}
                  {data.isFormSubmit && !data.emailId &&
                    (<span data-testid='reqEmail' className="invalid-feedback">{validationMessage.requireMsg}</span>)}
                </div>
                <div className="form-group mt-3">
                  <input
                    type="number"
                    className={error.phone.length > 0 || (data.isFormSubmit && !data.phone) ? "is-invalid form-control" : "form-control"}
                    name="phone"
                    title="Phone"
                    placeholder="Phone"
                    onChange={formValChange}
                    data-testid='empPhone'
                  />
                  {error.phone.length > 0 && (
                    <span className="invalid-feedback">{error.phone}</span>
                  )}
                  {data.isFormSubmit && !data.phone &&
                    (<span data-testid='reqPhone' className="invalid-feedback">{validationMessage.requireMsg}</span>)}
                </div>
                <div className="form-group mt-3">
                  <textarea
                    className='form-control'
                    placeholder="Address" name="address" onChange={formValChange} />
                </div>
                <div className="form-group mt-3">
                  <textarea maxLength={messageValidation.max} minLength={messageValidation.min}
                    className={error.experience.length > 0 || (data.isFormSubmit && !data.experience) ? "is-invalid form-control" : "form-control"}
                    data-testid='experience' placeholder="Experience" name="experience" onChange={formValChange} />

                  {error.experience.length > 0 && (
                    <span className="invalid-feedback">{error.experience}</span>
                  )}
                  {data.isFormSubmit && !data.experience &&
                    (<span data-testid='reqExperience' className="invalid-feedback">{validationMessage.requireMsg}</span>)}
                </div>


              </form>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button data-testid='applyJobBtn' type="submit" onClick={(e) => { applyJob(e) }} className="btn btn-block btn-danger mt-3 mb-1">Apply</button>
          {/* <Button onClick={props.onHide}>Close</Button> */}
        </Modal.Footer>
      </Modal>
    </>
  )
}


export default ApplyJobModal;