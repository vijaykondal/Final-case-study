import React, {useState} from "react";
import { Card } from "react-bootstrap";
import JobList from "./Jobs";
import ApplyJobModal from "./applyJobModal";
import briefcase from '../../Assets/icon/briefcase.png'
import location from '../../Assets/icon/location.png'
import rupee from '../../Assets/icon/rupee.png'


const JobCard = ({ jobList }) => {

   const [modalShow, setModalShow] = useState(false);
   const [editJob ,setEditJob] = useState();
    const applyJob = (job) => {
        setEditJob({jobId:job.jobId,jobRole:job.jobRole})
        setModalShow(true)       
    }
 

    return (
        <>
            {JobList && jobList.map((job) => {
                return <Card key={job.jobId} className="mb-2 card-container" onClick={()=> applyJob(job)}>
                    <Card.Body>
                        <Card.Title>{job.jobRole}</Card.Title>
                        <Card.Subtitle className="mb-2 text-muted">{job.company}</Card.Subtitle>
                        <div className="card-text">
                            <div className="row text-muted">
                                <div className="col-md-2 col-sm-12 pe-0" style={{width:'107px'}}>
                                    <img alt="BriefCase" src={briefcase} />
                                    <span className="mx-1">{job.expectedExperence} Yrs</span>
                                </div>
                                <div className="col-md-2 pe-0">
                                    <img alt="Rupee" src={rupee} />
                                    {job.salary}<span> PA</span>
                                </div>
                                <div className="col-md-2 pe-0">
                                    <img alt='Location' src={location} />
                                    {job.location}
                                </div>
                            </div>
                        </div>
                    </Card.Body>
                </Card>
            })}
           <ApplyJobModal 
             show={modalShow}
             onHide={() => setModalShow(false)}                                    
             data={editJob}
           />
        </>
    )
}

export default JobCard;