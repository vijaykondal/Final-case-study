import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { API_BASE_URL } from "../../constants";

export const applyJobAction = createAsyncThunk(
    'jobs/applyJob',
    async (obj) => {       
        const res = await axios.post(`${API_BASE_URL}/jobs`, JSON.parse(obj),{
            headers: {
                'Content-Type': 'application/json',
    }});
        return res;
    }
)

export const getJobListAction = createAsyncThunk(
    'jobs/getJobList',
    async () => {       
        const res = await axios.get(`${API_BASE_URL}/jobList`)
        return res.data;
    }
)