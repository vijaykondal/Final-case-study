import { render, screen } from "@testing-library/react";
import Conact from './contact'
import axios, { AxiosResponse } from 'axios';


describe('Test Contact component',()=>{
    afterEach(()=>{
        jest.restoreAllMocks();
    })

    it('componet shuold render addrees,phone,email', async()=>{
        const mockResponse={
            data:{
                "address": "Delhi",
                "phone": [
                  "(91) 123 654 3210",
                  "(91) 345 654 3211"
                ],
                "email": "abc@gmail.com"
              }
        };
        jest.spyOn(axios, 'get').mockResolvedValueOnce(mockResponse);

        render(<Conact/>)       
        expect(await screen.findByText('Delhi')).toBeInTheDocument();
        expect(await screen.findByText('abc@gmail.com')).toBeInTheDocument();
       const element= await screen.getByTestId('phone');       
       expect(element.textContent).toContain('(91) 123 654 3210(91) 345 654 3211');
        
    })



})