import React, { useEffect, useState } from "react";
import email from '../../Assets/icon/email.png';
import home from '../../Assets/icon/home.png'
import call from '../../Assets/icon/call.png'
import axios from "axios";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../constants";
import Loader from "../common-component/loader";
import GetInTouch from "./getinTouch";


const Contact = () => {
    const [contactData, setContactData] = useState({})
console.log('contat')
    useEffect(() => {
       let unSubscribe=false;
        const getApiData = async () => {
            try {
                const respose = await axios.get(`${API_BASE_URL}/contactData`);
              if(!unSubscribe){
                setContactData(respose.data);
              }
                
            } catch (error) {                
                    toast.error(error.message);  
                 }                         
            
        }
        getApiData();

        return ()=>{
           unSubscribe=true;
        }

    }, [])

    return (
        <>
            {!contactData && <Loader />}
            <div className="row">
                <div className="row py-4">
                    <div className="col-md-4 col-sm-12 text-center">
                        <div>
                            <img src={home} />
                        </div>
                        <div >
                            <h5>ADDRESS:</h5>
                            <p>{contactData?.address}</p>
                        </div>

                    </div>

                    <div className="col-md-4 col-sm-12 text-center">

                        <div>
                            <img src={call} />
                        </div>
                        <div>
                            <h5>PHONES:</h5>
                            <p data-testid='phone'>{contactData && contactData.phone && contactData.phone[0]}<br />
                                {contactData && contactData.phone && contactData.phone[1]}</p>
                        </div>

                    </div>

                    <div className="col-md-4 col-sm-12 text-center">

                        <div>
                            <img src={email} />
                        </div>
                        <div>
                            <h5>E-EMAIL</h5>
                            <p>{contactData?.email}</p>

                        </div>

                    </div>
                </div>
            </div>
            <GetInTouch></GetInTouch>
        </>
    )
}
export default Contact;